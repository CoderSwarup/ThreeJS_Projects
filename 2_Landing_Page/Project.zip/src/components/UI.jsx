import React from "react";
import Menu from "./Menu";

export default function UI() {
  return (
    <>
      <section className="h-screen w-screen flex items-center justify-center text-center p-8 lg:p-20 select-none">
        <div>
          <h1 className="mt-40 text-6xl text-white font-bold font-serif ">
            Pirate Shifudo 🏴‍☠️
          </h1>
          <p className="text-white">Best sea food in the world 🎣</p>
        </div>
      </section>
      <section className="h-screen w-screen flex items-center p-8 lg:p-20 select-none max-w-screen-xl mx-auto">
        <div className="-mt-40">
          <h2 className="text-2xl font-bold font-serif">Le Chef</h2>
          <h3 className="text-5xl font-bold font-serif">Broswick Chichaigne</h3>
          <p className="mt-2">
            Travelled the world seas and learned from the best 🌊. <br />
            We are proud to have him in our team and to serve you his best
            dishes. 🍽️
            <br />
            <br />
            If you stay late, you might even get to see him play the piano. 🎹
          </p>
        </div>
      </section>
      <section className="h-screen w-screen flex flex-col items-center p-8 lg:p-20 select-none max-w-screen-xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold text-center">Our Menu</h1>
          <p className="text-center font-serif text-md font-light">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta non
            doloribus minus nesciunt molestiae ratione voluptatum quisquam
            labore similique, voluptas ea cum tenetur expedita rerum repellat.
            Delectus sequi quod assumenda!
          </p>
        </div>
        <Menu />
      </section>
    </>
  );
}

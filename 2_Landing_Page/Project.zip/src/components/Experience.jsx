import {
  AccumulativeShadows,
  Environment,
  Gltf,
  RandomizedLight,
  Sky,
} from "@react-three/drei";
import React, { useRef } from "react";
import { degToRad } from "three/src/math/MathUtils.js";
import { Cook } from "./Cook";
import { useFrame, useThree } from "@react-three/fiber";
import useAppContext from "../hooks/useAppContext";

export default function Experience() {
  const viewPort = useThree((state) => state.viewport);
  const { foodItems } = useAppContext();

  return (
    <>
      {/* Restaurant */}
      <group>
        <Gltf src="models/Restaurant.glb" scale={0.18} castShadow />
        {/* <AccumulativeShadows
          temporal
          frames={35}
          alphaTest={0.65}
          scale={10}
          position={[0, 0.01, 0]}
          color="#EFBD4E"
        >
          <RandomizedLight
            amount={4}
            radius={9}
            intensity={0.55}
            ambient={0.25}
            position={[5, 5, -10]}
          />
          <RandomizedLight
            amount={4}
            radius={5}
            intensity={0.25}
            ambient={0.55}
            position={[-5, 5, -9]}
          />
        </AccumulativeShadows> */}
      </group>

      {/* Chracter */}
      <group
        position-x={2}
        position-y={-viewPort.height}
        rotation-y={degToRad(-20)}
      >
        <Cook position-y={-0.5} />
      </group>

      {/* Out WOrk Group */}
      <group position-y={-viewPort.height * 2}>
        {foodItems.map((ele, i) => (
          <FoorItem key={i} ele={ele} i={i} />
        ))}
      </group>
      <Environment preset="sunset" />
      <Sky />
    </>
  );
}

export const FoorItem = ({ ele, i }) => {
  const foodRef = useRef();
  const { currentFoodItem } = useAppContext();
  const viewPort = useThree((state) => state.viewport);

  useFrame((_, delta) => {
    if (foodRef.current) {
      const { x, y, z } = foodRef.current.position;
      const currentItem = currentFoodItem - i;
      //   console.log(foodRef.current.position);
      foodRef.current.position.x = currentItem * viewPort.width;
    }
  });
  return (
    <Gltf
      ref={foodRef}
      src={`models/${ele.model}.gltf`}
      scale={0.63}
      position-x={i}
    />
  );
};

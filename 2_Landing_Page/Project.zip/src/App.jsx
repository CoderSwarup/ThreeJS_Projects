import { Canvas } from "@react-three/fiber";
import "./App.css";
import { Scroll, ScrollControls } from "@react-three/drei";
import Experience from "./components/Experience";
import UI from "./components/UI";
import ContextProvider from "./context/ContextProvider";

function App() {
  return (
    <>
      <ContextProvider>
        <Canvas shadows camera={{ position: [0, 2, 8], fov: 30 }}>
          <color attach="background" args={["#dff0ff"]} />

          <ScrollControls pages={4}>
            <Scroll>
              <Experience />
            </Scroll>
            <Scroll html>
              <UI />
            </Scroll>
          </ScrollControls>
        </Canvas>
      </ContextProvider>
    </>
  );
}

export default App;
